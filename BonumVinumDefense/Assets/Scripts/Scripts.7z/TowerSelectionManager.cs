using UnityEngine;

public class TowerSelectionManager : MonoBehaviour
{
    private Tower selectedTower;
    private ITowerStrategy selectedStrategy;
    private TowerEffect selectedEffect;

    public void SelectTower(Tower tower)
    {
        selectedTower = tower;
        Debug.Log($"Selected Tower: {tower.name}");
    }

    public void SelectStrategy(string strategyType)
    {
        if (selectedTower == null) return;

        switch (strategyType)
        {
            case "SingleTarget":
                selectedStrategy = new SingleTargetStrategy();
                break;
            case "AOE":
                selectedStrategy = new AOETargetStrategy();
                break;
        }

        selectedTower.SetStrategy(selectedStrategy);
    }

    public void SelectEffect(string effectType)
    {
        if (selectedTower == null) return;

        switch (effectType)
        {
            case "Burn":
                selectedEffect = new BurnEffect(5, 3);
                break;
            case "Slow":
                selectedEffect = new SlowEffect(0.5f, 3);
                break;
            case "Poison":
                selectedEffect = new PoisonEffect(3, 5);
                break;
        }

        selectedTower.SetEffect(selectedEffect);
    }
}
