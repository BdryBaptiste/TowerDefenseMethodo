using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowEffect : TowerEffect
{
    public SlowEffect(float magnitude, int duration) : base("Slow", magnitude, duration) { }
}