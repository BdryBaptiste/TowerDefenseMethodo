using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoisonEffect : TowerEffect
{
    public PoisonEffect(float magnitude, int duration) : base("Poison", magnitude, duration) { }
}