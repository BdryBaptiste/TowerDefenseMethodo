using UnityEngine;

public class Tower : MonoBehaviour
{
    public float Range { get; protected set; } = 5f; // Attack range
    public int Damage { get; protected set; } = 10; // Damage dealt per attack
    public float Cooldown { get; protected set; } = 1f; // Attacks per second

    public Transform firePoint; // Point from where projectiles are fired
    public Transform visualHolder;

    public GameObject burnVisualPrefab;
    public GameObject slowVisualPrefab;
    public GameObject poisonVisualPrefab;

    private float attackCooldown = 0f; // Time left until the next attack

    // Attack behavior strategy
    public ITowerStrategy attackStrategy;

    // Special effect applied by the tower
    public TowerEffect effect;

    private void Update()
    {
        // Check cooldown
        attackCooldown -= Time.deltaTime;
        if (attackCooldown <= 0f)
        {
            Attack();
            attackCooldown = 1f / Cooldown;
        }
    }

    public void SetStrategy(ITowerStrategy strategy)
    {
        attackStrategy = strategy;
        Debug.Log($"Tower : Tower set to {strategy.GetType().Name} mode.");
    }

    public void SetEffect(TowerEffect newEffect)
    {
        effect = newEffect;
        UpdateTowerVisual();
        Debug.Log($"Tower : Tower effect set to {newEffect.GetType().Name}.");
    }

    public void Attack()
    {
        if (attackStrategy != null)
        {
            attackStrategy.Execute(this);
        }
        else
        {
            Debug.LogWarning("Tower : No attack strategy set!");
        }
    }

    public void ApplyEffect(Enemy enemy)
    {
        if (effect != null)
        {
            enemy.ApplyEffect(effect);
        }
    }

    private void UpdateTowerVisual()
    {
        if (visualHolder == null) return;

        // Remove existing child visuals
        foreach (Transform child in visualHolder)
        {
            Destroy(child.gameObject);
        }

        // Instantiate the correct visual prefab
        GameObject visualPrefab = effect.EffectType switch
        {
            "Burn" => burnVisualPrefab,
            "Slow" => slowVisualPrefab,
            "Poison" => poisonVisualPrefab,
            _ => null
        };

        if (visualPrefab != null)
        {
            Instantiate(visualPrefab, visualHolder.position, visualHolder.rotation, visualHolder);
        }
    }

    public void UpgradeRange(float amount)
    {
        Range += amount;
        Debug.Log($"Tower : Range upgraded to {Range}");
    }

    public void UpgradeDamage(int amount)
    {
        Damage += amount;
        Debug.Log($"Tower : Damage upgraded to {Damage}");
    }

    public void UpgradeCooldown(float amount)
    {
        Cooldown = Mathf.Max(0.1f, Cooldown - amount); // Prevent cooldown from going below 0.1
        Debug.Log($"Tower : Cooldown upgraded to {Cooldown}");
    }

    private void OnDrawGizmosSelected()
    {
        // Visualize the range of the tower in the editor
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, Range);
    }

    private void OnMouseDown()
    {
        FindObjectOfType<TowerSelectionManager>().SelectTower(this);
    }

}