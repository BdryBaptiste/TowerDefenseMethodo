using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BurnEffect : TowerEffect
{
    public BurnEffect(float magnitude, int duration) : base("Burn", magnitude, duration) { }
}
