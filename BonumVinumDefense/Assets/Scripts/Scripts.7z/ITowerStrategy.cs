public interface ITowerStrategy
{
    void Execute(Tower tower);
}