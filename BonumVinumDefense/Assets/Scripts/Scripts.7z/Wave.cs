using System.Collections.Generic;
public class Wave
    {
        public string waveName;
        public List<EnemySpawnInfo> enemies;
    }